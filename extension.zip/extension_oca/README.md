# Website Listener Browser Extension

A browser extension designed to track search clicks and manage shift reports for users of the planetaltig website.

## 📥 Installation Guide (Chrome/Edge/Brave)

This extension must be installed in Developer Mode.

### Step 1: Download the Extension
Download the extension package here: [`extension.zip`](/extension.zip)

### Step 2: Extract the ZIP File
1. Locate the downloaded `extension.zip` file.
2. Extract the contents to a folder on your computer (e.g., "website-listener-extension").

### Step 3: Load the Extension in Your Browser

1. Open your browser and navigate to the extensions management page:
   - **Chrome**: Go to `chrome://extensions/`
   - **Edge**: Go to `edge://extensions/`
   - **Brave**: Go to `brave://extensions/`
2. Enable **Developer Mode** by toggling the switch, usually located in the top-right corner.
3. Click the **"Load unpacked"** button.
4. Navigate to and select the extracted extension folder (the one containing `manifest.json`).
5. The extension should now be installed and ready to use!

## 📝 Support

If you encounter any issues during installation, please feel free to reach out for assistance.