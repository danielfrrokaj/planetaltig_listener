// supabase_auth.js

(function() {
    const AUTH_STORAGE_KEY = 'supabaseSession';
    // Client-side check: 48 hours (2 days). If the session is older than this, force full re-login.
    const SESSION_DURATION_MS = 48 * 60 * 60 * 1000; 
    // Access Token Check: If the session is older than 55 minutes, attempt to refresh the token.
    const ACCESS_TOKEN_EXPIRY_MS = 55 * 60 * 1000; 

    // Supabase Project Configuration
    const SUPABASE_URL = 'https://yxxladzheqoeecopdduv.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl4eGxhZHpoZXFvZWVjb3BkZHV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA5OTU1ODgsImV4cCI6MjA3NjU3MTU4OH0.zw6oBV_9CFkUPSduforms1oeDuXd66P8wWWF27M7Mio';

    /**
     * Retrieves the current session data from storage, checking for expiration and attempting refresh.
     * @returns {Promise<{accessToken: string, userId: string, username: string}|null>}
     */
    async function getSession() {
        return new Promise(resolve => {
            chrome.storage.local.get(AUTH_STORAGE_KEY, async (data) => {
                let session = data[AUTH_STORAGE_KEY];
                
                if (!session) {
                    resolve(null);
                    return;
                }

                const now = Date.now();
                
                // 1. Check Client-Side Max Lifetime (48 hours)
                if (now - session.timestamp > SESSION_DURATION_MS) {
                    console.log("Session expired client-side (48h limit). Forcing re-login.");
                    await clearSession();
                    resolve(null);
                    return;
                }
                
                // 2. Check Access Token Expiration (55 minutes) and attempt refresh
                if (now - session.timestamp > ACCESS_TOKEN_EXPIRY_MS) {
                    console.log("Access token likely expired. Attempting refresh...");
                    const refreshedSession = await refreshToken(session.refreshToken);
                    
                    if (refreshedSession) {
                        session = refreshedSession;
                        console.log("Token refreshed successfully.");
                    } else {
                        console.log("Token refresh failed. Forcing re-login.");
                        await clearSession();
                        resolve(null);
                        return;
                    }
                }
                
                resolve(session);
            });
        });
    }

    /**
     * Saves the session data to storage.
     * @param {Object} session - The session object containing access_token, user_id, username, and refresh_token.
     * @returns {Promise<void>}
     */
    function saveSession(session) {
        // Add creation timestamp
        session.timestamp = Date.now();
        return new Promise(resolve => {
            chrome.storage.local.set({ [AUTH_STORAGE_KEY]: session }, resolve);
        });
    }

    /**
     * Clears the session data from storage.
     * @returns {Promise<void>}
     */
    function clearSession() {
        return new Promise(resolve => {
            chrome.storage.local.remove(AUTH_STORAGE_KEY, resolve);
        });
    }
    
    /**
     * Uses the refresh token to get a new access token.
     * @param {string} currentRefreshToken
     * @returns {Promise<{accessToken: string, userId: string, username: string, refreshToken: string}|null>}
     */
    async function refreshToken(currentRefreshToken) {
        const url = `${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_ANON_KEY,
                },
                body: JSON.stringify({ refresh_token: currentRefreshToken })
            });

            const data = await response.json();

            if (!response.ok || data.error) {
                console.error("Refresh token failed:", data);
                return null;
            }

            const newSessionData = {
                accessToken: data.access_token,
                userId: data.user.id,
                username: data.user.email,
                refreshToken: data.refresh_token, // Supabase returns a new refresh token on refresh
            };
            
            await saveSession(newSessionData);
            return newSessionData;

        } catch (e) {
            console.error("Refresh token network error:", e);
            return null;
        }
    }

    /**
     * Handles user sign-in via email and password.
     * @param {string} email
     * @param {string} password
     * @returns {Promise<{user: Object|null, error: Object|null}>}
     */
    async function signIn(email, password) {
        const url = `${SUPABASE_URL}/auth/v1/token?grant_type=password`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_ANON_KEY,
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                return { user: null, error: data };
            }

            const userId = data.user.id;
            const accessToken = data.access_token;
            const refreshToken = data.refresh_token; // Capture the refresh token
            
            // Extract and save necessary data
            const sessionData = {
                accessToken: accessToken,
                userId: userId,
                username: data.user.email, // Using email as username
                refreshToken: refreshToken,
            };
            
            await saveSession(sessionData);
            return { user: sessionData, error: null };

        } catch (e) {
            console.error("Sign-in network error:", e);
            return { user: null, error: { message: 'Network error during sign-in.' } };
        }
    }

    /**
     * Handles user sign-out.
     * @returns {Promise<{error: Object|null}>}
     */
    async function signOut() {
        const session = await getSession();
        if (!session) {
            await clearSession();
            return { error: null };
        }

        const url = `${SUPABASE_URL}/auth/v1/logout`;
        
        try {
            // We use the access token to invalidate the session on the server side
            await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_ANON_KEY,
                    'Authorization': `Bearer ${session.accessToken}`
                }
            });
            
            // Clear local storage regardless of server response
            await clearSession();
            return { error: null };

        } catch (e) {
            console.error("Sign-out network error:", e);
            await clearSession(); // Ensure local state is cleared even if network fails
            return { error: null };
        }
    }

    // Expose functions globally
    window.getSession = getSession;
    window.signIn = signIn;
    window.signOut = signOut;
})();