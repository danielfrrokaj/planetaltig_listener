// supabase_api.js

(function() {
    // Supabase Project Configuration
    const SUPABASE_URL = 'https://yxxladzheqoeecopdduv.supabase.co';
    // NOTE: SUPABASE_ANON_KEY is kept here only for getProfile/updateProfile, 
    // which still use PostgREST directly.
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl4eGxhZHpoZXFvZWVjb3BkZHV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA5OTU1ODgsImV4cCI6MjA3NjU3MTU4OH0.zw6oBV_9CFkUPSduforms1oeDuXd66P8wWWF27M7Mio';
    
    // Edge Function URL for submitting reports
    const SUBMIT_REPORT_FUNCTION_URL = `${SUPABASE_URL}/functions/v1/submit-report`;

    /**
     * Generic fetch utility for Supabase PostgREST.
     * Used for profiles (GET/PATCH).
     * @param {string} endpoint - The table endpoint (e.g., 'profiles').
     * @param {string} method - HTTP method (GET, POST, PATCH).
     * @param {string} jwtToken - JWT token for authorization.
     * @param {Object} [body] - Request body for POST/PATCH.
     * @param {string} [query] - Query parameters (e.g., '?select=*').
     * @returns {Promise<{data: Object|null, error: Object|null}>}
     */
    async function supabaseFetch(endpoint, method, jwtToken, body = null, query = '') {
        const url = `${SUPABASE_URL}/rest/v1/${endpoint}${query}`;
        
        const authorizationHeader = `Bearer ${jwtToken}`;
        
        const headers = {
            'Content-Type': 'application/json',
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': authorizationHeader,
        };

        if (method === 'POST' || method === 'PATCH') {
            headers['Prefer'] = 'return=representation';
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: headers,
                body: body ? JSON.stringify(body) : null
            });

            if (!response.ok) {
                let errorBody = {};
                try {
                    errorBody = await response.json();
                } catch (e) {
                    errorBody = await response.text();
                }
                
                return { 
                    data: null, 
                    error: { 
                        status: response.status, // Added status code
                        message: `HTTP Error ${response.status}: ${response.statusText}`,
                        details: errorBody 
                    } 
                };
            }

            const data = await response.json();
            return { data, error: null };

        } catch (e) {
            console.error("Network or unexpected error during fetch:", e);
            return { 
                data: null, 
                error: { 
                    status: 0, // Use 0 for network errors
                    message: 'A network or unexpected error occurred.', 
                    details: e.message 
                } 
            };
        }
    }

    /**
     * Submits a shift report via the secure Edge Function.
     */
    async function submitShiftReport(reportData, jwtToken) {
        const authorizationHeader = `Bearer ${jwtToken}`;
        
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': authorizationHeader,
        };

        try {
            const response = await fetch(SUBMIT_REPORT_FUNCTION_URL, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(reportData)
            });

            const data = await response.json();

            if (!response.ok) {
                return { 
                    data: null, 
                    error: { 
                        status: response.status,
                        message: data.error || `HTTP Error ${response.status}: ${response.statusText}`,
                        details: data 
                    } 
                };
            }

            return { data, error: null };

        } catch (e) {
            console.error("Network or unexpected error during Edge Function call:", e);
            return { 
                data: null, 
                error: { 
                    status: 0,
                    message: 'A network or unexpected error occurred during report submission.', 
                    details: e.message 
                } 
            };
        }
    }

    /**
     * Fetches the user's profile data.
     */
    async function getProfile(userId, jwtToken) {
        const query = `?id=eq.${userId}&select=first_name,last_name,avatar_url`;
        return supabaseFetch('profiles', 'GET', jwtToken, null, query);
    }

    /**
     * Updates the user's profile data.
     */
    async function updateProfile(userId, profileData, jwtToken) {
        const query = `?id=eq.${userId}`;
        return supabaseFetch('profiles', 'PATCH', jwtToken, profileData, query);
    }

    // Expose functions globally
    window.submitShiftReport = submitShiftReport;
    window.getProfile = getProfile;
    window.updateProfile = updateProfile;
})();