// background.js
// Listens for messages or extension events

const STORAGE_KEY = 'searchLinkClicks';
const PICKUP_NOTES_KEY = 'pickupNotes';
const AUTH_STORAGE_KEY = 'supabaseSession'; // Key for session data

// Supabase Project Configuration (Required for service worker API calls)
const SUPABASE_URL = 'https://yxxladzheqoeecopdduv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl4eGxhZHpoZXFvZWVjb3BkZHV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA5OTU1ODgsImV4cCI6MjA3NjU3MTU4OH0.zw6oBV_9CFkUPSduforms1oeDuXd66P8wWWF27M7Mio';


chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed and ready.");
  // Initialize storage if not present
  chrome.storage.local.get([STORAGE_KEY, PICKUP_NOTES_KEY], (data) => {
    if (!data[STORAGE_KEY]) {
      chrome.storage.local.set({ [STORAGE_KEY]: [] });
    }
    if (!data[PICKUP_NOTES_KEY]) {
      chrome.storage.local.set({ [PICKUP_NOTES_KEY]: [] });
    }
  });
  
  // Initialize the periodic metrics update alarm
  const ALARM_NAME = 'metricsUpdateAlarm';
  // Changed interval from 5 minutes to 0.5 minutes (30 seconds)
  const INTERVAL_MINUTES = 0.5; 
  chrome.alarms.create(ALARM_NAME, {
      periodInMinutes: INTERVAL_MINUTES
  });
});

// Helper function to filter clicks by time
function filterClicks(clicks, hours) {
  const now = Date.now();
  const cutoff = now - (hours * 60 * 60 * 1000); // hours in milliseconds
  return clicks.filter(timestamp => timestamp >= cutoff).length;
}

// Helper function to calculate productivity rates
function calculateProductivity(clicks, pickups) {
    const totalClicks = clicks.length;
    const totalPickups = pickups.length;
    const appointmentPickups = pickups.filter(p => p.is_appointment).length;

    // Target Ratios for 100% Success
    // Updated: 100 calls per pickup = 100%
    const TARGET_CALLS_PER_PICKUP = 100; 
    // Target: 3 pickups per appointment = 100%
    const TARGET_PICKUPS_PER_APPOINTMENT = 3;

    // 1. Pickup Success Rate (Target: 100 calls per pickup)
    let pickupRate;
    if (totalPickups === 0) {
        pickupRate = 'N/A';
    } else {
        const actualCallsPerPickup = totalClicks / totalPickups;
        // Rate is calculated based on how close the actual ratio is to the target ratio, capped at 100%
        // Lower actualCallsPerPickup is better performance.
        const rawRate = (TARGET_CALLS_PER_PICKUP / actualCallsPerPickup) * 100;
        pickupRate = Math.min(100, rawRate).toFixed(2) + '%';
    }

    // 2. Appointment Success Rate (Target: 3 pickups per appointment)
    let appointmentRate;
    if (appointmentPickups === 0) {
        appointmentRate = 'N/A';
    } else {
        const actualPickupsPerAppointment = totalPickups / appointmentPickups;
        // Rate is calculated based on how close the actual ratio is to the target ratio, capped at 100%
        // Lower actualPickupsPerAppointment is better performance.
        const rawRate = (TARGET_PICKUPS_PER_APPOINTMENT / actualPickupsPerAppointment) * 100;
        appointmentRate = Math.min(100, rawRate).toFixed(2) + '%';
    }

    return {
        totalPickups,
        appointmentPickups,
        pickupRate,
        appointmentRate
    };
}

/**
 * Performs an authenticated UPSERT operation to update user_metrics.
 */
async function upsertMetrics(userId, callsLastHour, jwtToken) {
    const url = `${SUPABASE_URL}/rest/v1/user_metrics`;
    
    const headers = {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${jwtToken}`,
        'Prefer': 'resolution=merge-duplicates,return=representation' // Key for UPSERT
    };

    const body = {
        user_id: userId,
        calls_last_hour: callsLastHour,
        updated_at: new Date().toISOString()
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`Failed to upsert metrics (HTTP ${response.status}):`, errorBody);
            return false;
        }
        console.log(`Metrics upserted successfully for user ${userId}. Calls Last Hour: ${callsLastHour}`);
        return true;
    } catch (e) {
        console.error("Network error during metrics upsert:", e);
        return false;
    }
}

/**
 * Handles the periodic update of user metrics to Supabase.
 */
async function handleMetricsUpdate() {
    console.log("Running periodic metrics update...");
    
    // 1. Get session data
    const sessionData = await new Promise(resolve => {
        chrome.storage.local.get(AUTH_STORAGE_KEY, (data) => {
            resolve(data[AUTH_STORAGE_KEY]);
        });
    });

    if (!sessionData || !sessionData.accessToken) {
        console.log("User not authenticated. Skipping metrics update.");
        return;
    }

    // 2. Get click data
    const clickData = await new Promise(resolve => {
        chrome.storage.local.get(STORAGE_KEY, (data) => {
            resolve(data[STORAGE_KEY] || []);
        });
    });

    // 3. Calculate calls_last_hour (1 hour metric)
    const callsLastHour = filterClicks(clickData, 1);

    // 4. Upsert to Supabase
    await upsertMetrics(sessionData.userId, callsLastHour, sessionData.accessToken);
}

// Set up alarm listener
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'metricsUpdateAlarm') {
        handleMetricsUpdate();
    }
});


// Message listener for content scripts and popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "search_link_clicked") {
    chrome.storage.local.get(STORAGE_KEY, (data) => {
      const clicks = data[STORAGE_KEY] || [];
      clicks.push(msg.timestamp);
      // Keep only clicks from the last 8 hours to prevent storage bloat
      const eightHoursAgo = Date.now() - (8 * 60 * 60 * 1000);
      const filteredClicks = clicks.filter(timestamp => timestamp >= eightHoursAgo);
      chrome.storage.local.set({ [STORAGE_KEY]: filteredClicks }, () => {
        console.log('Search link click recorded:', msg.timestamp);
      });
    });
  } else if (msg.action === "save_pickup_note") {
    chrome.storage.local.get(PICKUP_NOTES_KEY, (data) => {
        const notes = data[PICKUP_NOTES_KEY] || [];
        const newNote = {
            id: Date.now(), // Simple unique ID
            note: msg.note,
            is_appointment: msg.is_appointment,
            timestamp: Date.now()
        };
        notes.unshift(newNote); // Add to the beginning
        chrome.storage.local.set({ [PICKUP_NOTES_KEY]: notes }, () => {
            sendResponse({ success: true, note: newNote });
        });
    });
    return true;
  } else if (msg.action === "delete_pickup_note") {
    chrome.storage.local.get(PICKUP_NOTES_KEY, (data) => {
        let notes = data[PICKUP_NOTES_KEY] || [];
        notes = notes.filter(note => note.id !== msg.id);
        chrome.storage.local.set({ [PICKUP_NOTES_KEY]: notes }, () => {
            sendResponse({ success: true });
        });
    });
    return true;
  } else if (msg.action === "get_stats") {
    // This replaces the old "get_click_stats" action
    chrome.storage.local.get([STORAGE_KEY, PICKUP_NOTES_KEY], (data) => {
      const clicks = data[STORAGE_KEY] || [];
      const pickups = data[PICKUP_NOTES_KEY] || [];

      const clickStats = {
        lastHour: filterClicks(clicks, 1),
        last8Hours: filterClicks(clicks, 8), // New 8-hour stat
        totalClicks: clicks.length
      };

      const productivityStats = calculateProductivity(clicks, pickups);

      sendResponse({
          clickStats: clickStats,
          productivityStats: productivityStats,
          pickupNotes: pickups
      });
    });
    return true; // Indicate that sendResponse will be called asynchronously
  }
});