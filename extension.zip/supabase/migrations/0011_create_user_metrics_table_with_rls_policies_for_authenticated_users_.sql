-- Create user_metrics table
CREATE TABLE public.user_metrics (
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
  calls_last_hour INTEGER DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS (REQUIRED for security)
ALTER TABLE public.user_metrics ENABLE ROW LEVEL SECURITY;

-- Policy: Users can read their own metrics
CREATE POLICY "Users can read their own metrics" ON public.user_metrics 
FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Policy: Users can insert their own metrics (only once, handled by upsert)
CREATE POLICY "Users can insert their own metrics" ON public.user_metrics 
FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own metrics
CREATE POLICY "Users can update their own metrics" ON public.user_metrics 
FOR UPDATE TO authenticated USING (auth.uid() = user_id);