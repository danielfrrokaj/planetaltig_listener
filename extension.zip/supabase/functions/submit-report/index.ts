import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Content-Type': 'application/json',
}

serve(async (req) => {
  // Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }
  
  const authHeader = req.headers.get('Authorization')
  
  if (!authHeader) {
    return new Response(JSON.stringify({ error: 'Unauthorized: Missing Authorization header' }), { 
      status: 401, 
      headers: corsHeaders 
    })
  }
  
  const token = authHeader.replace('Bearer ', '')
  
  try {
    const {
      user_id,
      caller_username,
      working_hours,
      total_calls,
      total_pickups,
      total_appointments,
      report_notes
    } = await req.json()

    // Initialize Supabase client with the JWT token for RLS enforcement
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: `Bearer ${token}` },
        },
      }
    )

    // Check if the user ID in the payload matches the authenticated user ID (optional but good practice)
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user || user.id !== user_id) {
        console.error("JWT verification failed or user ID mismatch:", authError);
        return new Response(JSON.stringify({ error: 'Unauthorized: Invalid token or user ID mismatch' }), { 
            status: 401, 
            headers: corsHeaders 
        })
    }

    // Insert data into shift_reports table
    const { data, error } = await supabase
      .from('shift_reports')
      .insert([
        {
          user_id,
          caller_username,
          working_hours,
          total_calls,
          total_pickups,
          total_appointments,
          report_notes
        },
      ])
      .select()

    if (error) {
      console.error('Supabase Insert Error:', error)
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: corsHeaders,
      })
    }

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: corsHeaders,
    })

  } catch (error) {
    console.error('Request processing error:', error)
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: corsHeaders,
    })
  }
})